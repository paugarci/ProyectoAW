<?php

namespace es\ucm\fdi\aw\DTO;

require_once 'includes/config.php';

abstract class DTO
{
}
